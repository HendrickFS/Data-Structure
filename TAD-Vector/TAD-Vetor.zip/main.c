#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include "tad-vector.h"



int main(){
    return 0;
}